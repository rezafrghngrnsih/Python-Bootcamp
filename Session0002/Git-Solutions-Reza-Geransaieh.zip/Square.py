n = int(input())
for i in range(1, n+1):
    print('\n')
    for j in range(1, n+1):
        if (i == 1) or (i == n):
            print('*', end='')
        elif 1 < i < n:
            x = (n-2) * ' '
            print(f'*{x}*')
            break
